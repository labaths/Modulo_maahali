# -*- coding: utf-8 -*-
{
    'name': "Mahaali Module",  # Module title
    'summary': "Manage email marketing campaigns easily",  # Module subtitle phrase
    'description': """
Manage Library
==============
Description related to library.
    """,  # Supports reStructuredText(RST) format
    'author': "Labat Heisen",
    'website': "http://www.maahali.com",
    'category': 'Tools',
    'version': '1.0.0',
    'depends': ['base'],

    'data': [
        'security/maahali_security.xml',
        'security/ir.model.access.csv',
        'views/view.xml',
        'views/partner.xml',
        'reports/reporte_maahali.xml',
        # Si no carga demo data, este siempre carga
        #'demo/demo.xml',              
    ],
    # This demo data files will be loaded if db initialize with demo data (commented becaues file is not added in this example)
   # 'demo': [
   #     'demo/demo.xml',
    #],
    'installable': True,
    'application': True,    
}
