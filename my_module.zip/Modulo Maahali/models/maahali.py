from datetime import date
from odoo import models, fields, api
from odoo.exceptions import UserError
from odoo.tools.translate import _
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from odoo.exceptions import ValidationError

class autoCampaign(models.Model):
    _name = 'my_module.maahali'
    _description ='Estructura de una campaña automatica'
     
    name = fields.Char('campaign Title ', required= True)
    asunto = fields.Char('Subject ', required= True)
    subtitulo = fields.Char('Subtitulo ', required= True)
    destino = fields.Many2many('res.partner', string='Clients')
    cuerpo =fields.Html('Campaign Body', required= True)
    fechaCreacion = fields.Date(string="Creation Date" ,default=date.today())
    fechaEnvio = fields.Date('Start Date ')
    autor = fields.Many2one('res.users','Author', default=lambda self: self.env.user)
    lanzar = fields.Boolean('Launch')
    state = fields.Selection([
        ('desactivated', 'Desactivated'),
        ('ready', 'Ready'),
        ('in_process', 'In Process'),
        ('completed', 'Completed')],
        'State', default="desactivated")
    @api.model
    def is_allowed_transition(self, old_state, new_state):
        allowed = [('desactivated', 'ready'),
                   ('ready', 'in_process'),
                   ('in_process', 'ready'),
                   ('completed', 'desactivated'),
                   ('in_process', 'completed'),
                   ('completed', 'in_process')]
        return (old_state, new_state) in allowed
    def change_state(self, new_state):
        for maahali in self:
            if maahali.is_allowed_transition(maahali.state, new_state):
                maahali.state = new_state
            else:
                message = _('Moving from %s to %s is not allowd') % (maahali.state, new_state)
                raise UserError(message)

    

    def getCurrentUser(self):
        return self.env.user

    def make_preparada(self):
        self.change_state('ready')
    
    def make_en_proceso(self):
        self.change_state('in_process')
        self.enviarEmail()

    
    def make_desactivada(self):
        self.change_state('desactivated')
    def make_completada(self):
        self.change_state('completed')

    def change_fechaEnvio(self):
        self.ensure_one()
        self.fechEnvio = fields.Date.today()

    def enviarEmail(self):
        msg = MIMEMultipart()
        message = self.cuerpo
        password = "Saharalibre"
        msg['From'] = "labaths22@gmail.com"
        msg['To'] = 'info@hs-enterprise.es'
        msg['Subject'] = self.asunto
        msg.attach(MIMEText(message, 'html'))
        server = smtplib.SMTP('smtp.gmail.com: 587')
        server.starttls()
        server.login(msg['From'], password)
        server.sendmail(msg['From'], msg['To'], msg.as_string())
        server.quit()
 
        print ("successfully sent email to %s:" % (msg['To']))

    #Restringimos que se registra fecha de envio inferior a la actual
    @api.constrains('fechaEnvio')
    def _check_something(self):
        for record in self:
            if record.fechaEnvio < self.fechaCreacion:
                raise ValidationError("Your date %s is invalid, it has to be today or later." % record.fechaEnvio)

   
    #Añadimos las campañas a sus autores

    class ResPartner(models.Model):
        _inherit = 'res.partner'

        authored_campaign_ids = fields.Many2many(
             'my_module.maahali',
             string='Campaigns',
    )